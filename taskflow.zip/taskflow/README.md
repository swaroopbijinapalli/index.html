# TaskFlow — Team Task Manager

A full-stack team productivity application with role-based access control, real-time task tracking, and a beautiful dark dashboard.

![TaskFlow Dashboard](https://img.shields.io/badge/Status-Live-brightgreen) ![Node](https://img.shields.io/badge/Node-22+-blue) ![React](https://img.shields.io/badge/React-18-61DAFB)

---

## 🚀 Live Demo

- **App:** `https://your-app.railway.app` *(replace after deploy)*
- **API Health:** `https://your-api.railway.app/api/health`

### Demo Credentials
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@demo.com | admin123 |
| Member | member@demo.com | member123 |

---

## ✨ Features

### Authentication
- JWT-based signup & login
- Persistent sessions (7-day tokens)
- Role selection on signup (Admin / Member)

### Projects
- Create, edit, archive, delete projects
- Progress tracking (task completion %)
- Due dates & status management
- Member management (add/remove by email)

### Tasks
- Full CRUD with Kanban board view
- List view with filtering
- Status: `todo` → `in_progress` → `review` → `done`
- Priority levels: low / medium / high / critical
- Task assignment to team members
- Due date tracking with overdue alerts
- Comments system per task

### Dashboard
- Summary stats (total, in-progress, done, overdue)
- Recent activity feed
- Overdue tasks panel
- Priority breakdown chart
- Quick actions

### Role-Based Access Control
| Feature | Admin | Member |
|---------|-------|--------|
| View all projects | ✅ | ❌ (own only) |
| Create projects | ✅ | ✅ |
| Delete any project | ✅ | ❌ (own only) |
| Manage members | ✅ | ❌ |
| Change user roles | ✅ | ❌ |
| Create tasks | ✅ | ✅ (in projects) |
| Delete any task | ✅ | ❌ (reporter only) |

---

## 🏗️ Tech Stack

### Backend
- **Runtime:** Node.js (Express.js)
- **Database:** SQLite via sql.js (zero native deps)
- **Auth:** JWT (jsonwebtoken) + bcryptjs
- **Validation:** express-validator
- **IDs:** uuid v4

### Frontend
- **Framework:** React 18 + React Router v6
- **HTTP:** Axios with interceptors
- **UI:** Custom CSS design system (no component library)
- **Fonts:** Syne (display) + DM Sans (body) + Space Mono
- **Icons:** lucide-react
- **Toasts:** react-hot-toast
- **Date utils:** date-fns

---

## 📁 Project Structure

```
taskflow/
├── backend/
│   ├── routes/
│   │   ├── auth.js          # POST /signup, /login, GET /me
│   │   ├── projects.js      # CRUD + members
│   │   ├── tasks.js         # CRUD + comments
│   │   ├── users.js         # User listing & role management
│   │   └── dashboard.js     # Stats & analytics
│   ├── middleware/
│   │   └── auth.js          # JWT auth + RBAC helpers
│   ├── db.js                # sql.js database wrapper
│   ├── server.js            # Express app entry
│   └── railway.toml         # Deployment config
└── frontend/
    └── src/
        ├── context/
        │   └── AuthContext.jsx
        ├── pages/
        │   ├── LoginPage.jsx
        │   ├── SignupPage.jsx
        │   ├── DashboardPage.jsx
        │   ├── ProjectsPage.jsx
        │   ├── ProjectDetailPage.jsx
        │   └── TasksPage.jsx
        ├── components/
        │   └── Layout.jsx
        └── utils/
            └── api.js
```

---

## 🛠️ Local Development

### Prerequisites
- Node.js 18+
- npm or yarn

### Backend Setup
```bash
cd backend
cp .env.example .env
# Edit .env with your values
npm install
npm run dev
# API runs on http://localhost:5000
```

### Frontend Setup
```bash
cd frontend
cp .env.example .env
# Set REACT_APP_API_URL=http://localhost:5000/api
npm install
npm start
# App runs on http://localhost:3000
```

---

## 🚂 Deploying to Railway

### Deploy Backend

1. Push code to GitHub
2. Go to [Railway](https://railway.app) → **New Project** → **Deploy from GitHub**
3. Select your repo, choose the `backend` folder (or set Root Directory to `backend`)
4. Add environment variables:
   ```
   JWT_SECRET=your_secure_random_string_here
   PORT=5000
   FRONTEND_URL=https://your-frontend-url.com
   ```
5. Railway auto-detects Node.js and deploys

### Deploy Frontend

**Option A: Railway Static Site**
1. New Service → GitHub → `frontend` folder
2. Build Command: `npm run build`
3. Start Command: `npx serve -s build`
4. Add env var: `REACT_APP_API_URL=https://your-backend.railway.app/api`

**Option B: Vercel (Recommended for React)**
1. Import GitHub repo on [vercel.com](https://vercel.com)
2. Set Root Directory to `frontend`
3. Add env: `REACT_APP_API_URL=https://your-backend.railway.app/api`

---

## 📡 API Reference

### Auth
```
POST /api/auth/signup   { name, email, password, role }
POST /api/auth/login    { email, password }
GET  /api/auth/me       → current user
```

### Projects
```
GET    /api/projects
POST   /api/projects              { name, description, due_date }
GET    /api/projects/:id
PUT    /api/projects/:id          { name, description, status, due_date }
DELETE /api/projects/:id
POST   /api/projects/:id/members  { email, role }
DELETE /api/projects/:id/members/:userId
```

### Tasks
```
GET    /api/tasks?project_id=&status=&priority=&assignee_id=
POST   /api/tasks                 { title, project_id, description, status, priority, assignee_id, due_date }
GET    /api/tasks/:id             → task + comments
PUT    /api/tasks/:id
DELETE /api/tasks/:id
POST   /api/tasks/:id/comments    { content }
```

### Dashboard
```
GET /api/dashboard/stats  → stats, recentTasks, overdueTasks, priorityBreakdown
```

### Users
```
GET /api/users
GET /api/users/:id
PUT /api/users/:id/role   { role }  (admin only)
```

---

## 🔒 Security Notes

- All passwords hashed with bcrypt (salt rounds: 10)
- JWT tokens expire in 7 days
- Route-level RBAC middleware on all protected endpoints
- Input validation via express-validator
- CORS configured for specific frontend origin

---

## 📝 License

MIT — Built for TaskFlow Assignment
