const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'taskflow.db');

let db = null;

function saveToDisk() {
  if (!db || !db._sqliteDb) return;
  try {
    const data = db._sqliteDb.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (e) {
    console.error('DB save error:', e.message);
  }
}

function normalizeParam(v) {
  if (v === undefined) return null;
  return v;
}

function createWrapper(sqliteDb) {
  const wrapper = {
    _sqliteDb: sqliteDb,
    prepare(sql) {
      return {
        run(...params) {
          sqliteDb.run(sql, params.map(normalizeParam));
          saveToDisk();
          return { changes: sqliteDb.getRowsModified() };
        },
        get(...params) {
          const stmt = sqliteDb.prepare(sql);
          stmt.bind(params.map(normalizeParam));
          if (stmt.step()) {
            const row = stmt.getAsObject();
            stmt.free();
            return row;
          }
          stmt.free();
          return undefined;
        },
        all(...params) {
          const stmt = sqliteDb.prepare(sql);
          stmt.bind(params.map(normalizeParam));
          const rows = [];
          while (stmt.step()) rows.push(stmt.getAsObject());
          stmt.free();
          return rows;
        }
      };
    },
    exec(sql) {
      sqliteDb.run(sql);
      saveToDisk();
    },
    pragma() {}
  };
  return wrapper;
}

async function initDb() {
  const SQL = await initSqlJs();
  let sqliteDb;

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    sqliteDb = new SQL.Database(fileBuffer);
  } else {
    sqliteDb = new SQL.Database();
  }

  db = createWrapper(sqliteDb);

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'member',
      avatar_color TEXT DEFAULT '#6366f1',
      created_at DATETIME DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      status TEXT DEFAULT 'active',
      owner_id TEXT NOT NULL,
      created_at DATETIME DEFAULT (datetime('now')),
      due_date DATETIME
    );

    CREATE TABLE IF NOT EXISTS project_members (
      project_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'member',
      joined_at DATETIME DEFAULT (datetime('now')),
      PRIMARY KEY (project_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      status TEXT DEFAULT 'todo',
      priority TEXT DEFAULT 'medium',
      project_id TEXT NOT NULL,
      assignee_id TEXT,
      reporter_id TEXT NOT NULL,
      due_date DATETIME,
      created_at DATETIME DEFAULT (datetime('now')),
      updated_at DATETIME DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS comments (
      id TEXT PRIMARY KEY,
      content TEXT NOT NULL,
      task_id TEXT NOT NULL,
      author_id TEXT NOT NULL,
      created_at DATETIME DEFAULT (datetime('now'))
    );
  `);

  setInterval(saveToDisk, 30000);

  console.log('✅ Database initialized');
  return db;
}

function getDb() {
  if (!db) throw new Error('DB not initialized. Call initDb() first.');
  return db;
}

module.exports = { getDb, initDb };
