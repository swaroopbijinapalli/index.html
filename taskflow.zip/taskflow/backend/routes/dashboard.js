const express = require('express');
const { getDb } = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/dashboard/stats
router.get('/stats', (req, res) => {
  const db = getDb();
  const userId = req.user.id;
  const isAdmin = req.user.role === 'admin';

  const projectFilter = isAdmin
    ? ''
    : `AND t.project_id IN (SELECT project_id FROM project_members WHERE user_id = '${userId}')`;

  const taskStats = db.prepare(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN status = 'todo' THEN 1 ELSE 0 END) as todo,
      SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
      SUM(CASE WHEN status = 'review' THEN 1 ELSE 0 END) as review,
      SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as done,
      SUM(CASE WHEN due_date < datetime('now') AND status != 'done' THEN 1 ELSE 0 END) as overdue
    FROM tasks t WHERE 1=1 ${projectFilter}
  `).get();

  const myTasks = db.prepare(`
    SELECT COUNT(*) as count FROM tasks WHERE assignee_id = ?
  `).get(userId);

  const projectCount = isAdmin
    ? db.prepare('SELECT COUNT(*) as count FROM projects').get()
    : db.prepare('SELECT COUNT(*) as count FROM project_members WHERE user_id = ?').get(userId);

  const recentTasks = db.prepare(`
    SELECT t.*, p.name as project_name, u.name as assignee_name, u.avatar_color as assignee_color
    FROM tasks t
    LEFT JOIN projects p ON t.project_id = p.id
    LEFT JOIN users u ON t.assignee_id = u.id
    WHERE 1=1 ${projectFilter}
    ORDER BY t.updated_at DESC LIMIT 8
  `).all();

  const overdueTasks = db.prepare(`
    SELECT t.*, p.name as project_name, u.name as assignee_name
    FROM tasks t
    LEFT JOIN projects p ON t.project_id = p.id
    LEFT JOIN users u ON t.assignee_id = u.id
    WHERE t.due_date < datetime('now') AND t.status != 'done' ${projectFilter}
    ORDER BY t.due_date ASC LIMIT 5
  `).all();

  const priorityBreakdown = db.prepare(`
    SELECT priority, COUNT(*) as count
    FROM tasks t WHERE status != 'done' ${projectFilter}
    GROUP BY priority
  `).all();

  res.json({
    stats: {
      ...taskStats,
      my_tasks: myTasks.count,
      projects: projectCount.count
    },
    recentTasks,
    overdueTasks,
    priorityBreakdown
  });
});

module.exports = router;
