const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../db');
const { authenticate, requireProjectAccess } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/tasks?project_id=&assignee_id=&status=
router.get('/', (req, res) => {
  const db = getDb();
  const { project_id, assignee_id, status, priority } = req.query;

  let query = `
    SELECT t.*,
      u1.name as assignee_name, u1.avatar_color as assignee_color,
      u2.name as reporter_name,
      p.name as project_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id
  `;

  const conditions = [];
  const params = [];

  if (req.user.role !== 'admin') {
    conditions.push(`t.project_id IN (
      SELECT project_id FROM project_members WHERE user_id = ?
    )`);
    params.push(req.user.id);
  }

  if (project_id) { conditions.push('t.project_id = ?'); params.push(project_id); }
  if (assignee_id) { conditions.push('t.assignee_id = ?'); params.push(assignee_id); }
  if (status) { conditions.push('t.status = ?'); params.push(status); }
  if (priority) { conditions.push('t.priority = ?'); params.push(priority); }

  if (conditions.length) query += ' WHERE ' + conditions.join(' AND ');
  query += ' ORDER BY t.created_at DESC';

  const tasks = db.prepare(query).all(...params);
  res.json({ tasks });
});

// POST /api/tasks
router.post('/', [
  body('title').trim().isLength({ min: 1, max: 200 }),
  body('project_id').notEmpty(),
  body('priority').optional().isIn(['low', 'medium', 'high', 'critical']),
  body('status').optional().isIn(['todo', 'in_progress', 'review', 'done']),
  body('due_date').optional().isISO8601(),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const db = getDb();
  const { title, description, project_id, assignee_id, priority, status, due_date } = req.body;

  // Check project access
  if (req.user.role !== 'admin') {
    const member = db.prepare(
      'SELECT * FROM project_members WHERE project_id = ? AND user_id = ?'
    ).get(project_id, req.user.id);
    if (!member) return res.status(403).json({ error: 'No access to this project' });
  }

  const id = uuidv4();
  db.prepare(`
    INSERT INTO tasks (id, title, description, project_id, assignee_id, reporter_id, priority, status, due_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, title, description || null, project_id, assignee_id || null, req.user.id,
    priority || 'medium', status || 'todo', due_date || null);

  const task = db.prepare(`
    SELECT t.*, u1.name as assignee_name, u1.avatar_color as assignee_color,
      u2.name as reporter_name, p.name as project_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE t.id = ?
  `).get(id);

  res.status(201).json({ task });
});

// GET /api/tasks/:taskId
router.get('/:taskId', (req, res) => {
  const db = getDb();
  const task = db.prepare(`
    SELECT t.*, u1.name as assignee_name, u1.avatar_color as assignee_color,
      u2.name as reporter_name, p.name as project_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE t.id = ?
  `).get(req.params.taskId);

  if (!task) return res.status(404).json({ error: 'Task not found' });

  const comments = db.prepare(`
    SELECT c.*, u.name as author_name, u.avatar_color
    FROM comments c JOIN users u ON c.author_id = u.id
    WHERE c.task_id = ? ORDER BY c.created_at ASC
  `).all(req.params.taskId);

  res.json({ task, comments });
});

// PUT /api/tasks/:taskId
router.put('/:taskId', (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.taskId);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const { title, description, status, priority, assignee_id, due_date } = req.body;

  db.prepare(`
    UPDATE tasks SET
      title = COALESCE(?, title),
      description = COALESCE(?, description),
      status = COALESCE(?, status),
      priority = COALESCE(?, priority),
      assignee_id = CASE WHEN ? IS NOT NULL THEN ? ELSE assignee_id END,
      due_date = COALESCE(?, due_date),
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(
    title || null, description || null, status || null, priority || null,
    assignee_id !== undefined ? assignee_id : null,
    assignee_id !== undefined ? assignee_id : null,
    due_date || null, req.params.taskId
  );

  const updated = db.prepare(`
    SELECT t.*, u1.name as assignee_name, u1.avatar_color as assignee_color,
      u2.name as reporter_name, p.name as project_name
    FROM tasks t
    LEFT JOIN users u1 ON t.assignee_id = u1.id
    LEFT JOIN users u2 ON t.reporter_id = u2.id
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE t.id = ?
  `).get(req.params.taskId);

  res.json({ task: updated });
});

// DELETE /api/tasks/:taskId
router.delete('/:taskId', (req, res) => {
  const db = getDb();
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.taskId);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  if (req.user.id !== task.reporter_id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Only reporter or admin can delete' });
  }

  db.prepare('DELETE FROM tasks WHERE id = ?').run(req.params.taskId);
  res.json({ message: 'Task deleted' });
});

// POST /api/tasks/:taskId/comments
router.post('/:taskId/comments', [
  body('content').trim().isLength({ min: 1 }),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const db = getDb();
  const id = uuidv4();
  db.prepare(
    'INSERT INTO comments (id, content, task_id, author_id) VALUES (?, ?, ?, ?)'
  ).run(id, req.body.content, req.params.taskId, req.user.id);

  const comment = db.prepare(`
    SELECT c.*, u.name as author_name, u.avatar_color
    FROM comments c JOIN users u ON c.author_id = u.id
    WHERE c.id = ?
  `).get(id);

  res.status(201).json({ comment });
});

module.exports = router;
