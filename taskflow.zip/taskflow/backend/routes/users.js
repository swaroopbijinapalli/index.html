const express = require('express');
const { getDb } = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// GET /api/users - list users (admin only or for member lookup)
router.get('/', (req, res) => {
  const db = getDb();
  const users = db.prepare(
    'SELECT id, name, email, role, avatar_color, created_at FROM users ORDER BY name ASC'
  ).all();
  res.json({ users });
});

// GET /api/users/:userId
router.get('/:userId', (req, res) => {
  const db = getDb();
  const user = db.prepare(
    'SELECT id, name, email, role, avatar_color, created_at FROM users WHERE id = ?'
  ).get(req.params.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user });
});

// PUT /api/users/:userId/role (admin only)
router.put('/:userId/role', requireAdmin, (req, res) => {
  const { role } = req.body;
  if (!['admin', 'member'].includes(role)) {
    return res.status(400).json({ error: 'Role must be admin or member' });
  }
  const db = getDb();
  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.params.userId);
  res.json({ message: 'Role updated' });
});

module.exports = router;
