import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { formatDistanceToNow, parseISO, isPast } from 'date-fns';
import { AlertTriangle, Plus, X, Filter } from 'lucide-react';

const PRIORITY_COLORS = { low: '#64748b', medium: '#f59e0b', high: '#f97316', critical: '#ff3366' };
const STATUS_LABELS = { todo: 'To Do', in_progress: 'In Progress', review: 'Review', done: 'Done' };

function Avatar({ name, color, size = 28 }) {
  const initials = name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  return (
    <div style={{
      width: size, height: size, borderRadius: 8, flexShrink: 0,
      background: color || '#6366f1', display: 'flex', alignItems: 'center',
      justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: size * 0.3
    }}>{initials}</div>
  );
}

function TaskDetailModal({ taskId, members, onClose, onSaved, onDeleted }) {
  const [task, setTask] = useState(null);
  const [comments, setComments] = useState([]);
  const [form, setForm] = useState({});
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get(`/tasks/${taskId}`).then(res => {
      setTask(res.data.task);
      setComments(res.data.comments);
      const t = res.data.task;
      setForm({
        title: t.title, description: t.description || '',
        status: t.status, priority: t.priority,
        assignee_id: t.assignee_id || '',
        due_date: t.due_date ? t.due_date.split('T')[0] : ''
      });
    });
  }, [taskId]);

  const handleSave = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.put(`/tasks/${taskId}`, form);
      toast.success('Task updated');
      onSaved(res.data.task);
      onClose();
    } catch (err) {
      toast.error('Failed to update');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this task?')) return;
    await api.delete(`/tasks/${taskId}`);
    toast.success('Task deleted');
    onDeleted(taskId);
    onClose();
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const res = await api.post(`/tasks/${taskId}/comments`, { content: newComment });
    setComments(c => [...c, res.data.comment]);
    setNewComment('');
  };

  if (!task) return (
    <div className="modal-overlay">
      <div className="modal" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 200 }}>
        <span style={{ color: 'var(--text-muted)' }}>Loading...</span>
      </div>
    </div>
  );

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 600 }}>
        <div className="modal-header">
          <div className="modal-title">Edit Task</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSave}>
            <div className="form-group">
              <label className="form-label">Title</label>
              <input className="form-input" value={form.title || ''} onChange={e => setForm({ ...form, title: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea className="form-textarea" value={form.description || ''} onChange={e => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Status</label>
                <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="todo">To Do</option>
                  <option value="in_progress">In Progress</option>
                  <option value="review">Review</option>
                  <option value="done">Done</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Priority</label>
                <select className="form-select" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="critical">Critical</option>
                </select>
              </div>
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Assignee</label>
                <select className="form-select" value={form.assignee_id} onChange={e => setForm({ ...form, assignee_id: e.target.value })}>
                  <option value="">Unassigned</option>
                  {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Due Date</label>
                <input className="form-input" type="date" value={form.due_date || ''}
                  onChange={e => setForm({ ...form, due_date: e.target.value })} />
              </div>
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: 8 }}>
              Project: <strong style={{ color: 'var(--text-secondary)' }}>{task.project_name}</strong>
              {' · '}Reporter: <strong style={{ color: 'var(--text-secondary)' }}>{task.reporter_name}</strong>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-danger btn-sm" onClick={handleDelete}>Delete</button>
              <div style={{ flex: 1 }} />
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>

          <div style={{ marginTop: 20, borderTop: '1px solid var(--border)', paddingTop: 16 }}>
            <div style={{ fontWeight: 700, fontSize: '0.82rem', marginBottom: 10 }}>Comments ({comments.length})</div>
            <div style={{ maxHeight: 160, overflowY: 'auto', marginBottom: 10 }}>
              {comments.map(c => (
                <div key={c.id} className="comment">
                  <Avatar name={c.author_name} color={c.avatar_color} size={28} />
                  <div className="comment-body">
                    <div className="comment-header">
                      <span className="comment-author">{c.author_name}</span>
                      <span className="comment-time">{formatDistanceToNow(parseISO(c.created_at), { addSuffix: true })}</span>
                    </div>
                    <div className="comment-text">{c.content}</div>
                  </div>
                </div>
              ))}
              {comments.length === 0 && <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>No comments yet.</div>}
            </div>
            <form onSubmit={handleComment} style={{ display: 'flex', gap: 8 }}>
              <input className="form-input" style={{ flex: 1 }} placeholder="Write a comment..."
                value={newComment} onChange={e => setNewComment(e.target.value)} />
              <button type="submit" className="btn btn-secondary btn-sm">Post</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TasksPage() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState(null);
  const [filters, setFilters] = useState({ status: '', priority: '', assignee_id: '' });

  const fetchTasks = () => {
    const params = new URLSearchParams();
    if (filters.status) params.set('status', filters.status);
    if (filters.priority) params.set('priority', filters.priority);
    if (filters.assignee_id) params.set('assignee_id', filters.assignee_id);

    api.get(`/tasks?${params}`).then(res => {
      setTasks(res.data.tasks);
      setLoading(false);
    });
  };

  useEffect(() => { fetchTasks(); }, [filters]);
  useEffect(() => { api.get('/users').then(res => setAllUsers(res.data.users)); }, []);

  const handleTaskSaved = (saved) => {
    setTasks(prev => {
      const idx = prev.findIndex(t => t.id === saved.id);
      if (idx >= 0) {
        const next = [...prev]; next[idx] = saved; return next;
      }
      return [saved, ...prev];
    });
  };

  const handleTaskDeleted = (id) => setTasks(prev => prev.filter(t => t.id !== id));

  const myTasks = tasks.filter(t => t.assignee_id === user?.id);
  const overdueTasks = tasks.filter(t => t.due_date && isPast(parseISO(t.due_date)) && t.status !== 'done');

  return (
    <>
      <div className="page-header">
        <div>
          <div className="page-title">All Tasks</div>
          <div className="page-subtitle">{tasks.length} task{tasks.length !== 1 ? 's' : ''} found</div>
        </div>
      </div>

      <div className="page-body">
        {/* Filters */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 24, alignItems: 'center', flexWrap: 'wrap' }}>
          <Filter size={16} color="var(--text-muted)" />
          <select className="form-select" style={{ width: 'auto' }}
            value={filters.status} onChange={e => setFilters({ ...filters, status: e.target.value })}>
            <option value="">All Statuses</option>
            <option value="todo">To Do</option>
            <option value="in_progress">In Progress</option>
            <option value="review">Review</option>
            <option value="done">Done</option>
          </select>
          <select className="form-select" style={{ width: 'auto' }}
            value={filters.priority} onChange={e => setFilters({ ...filters, priority: e.target.value })}>
            <option value="">All Priorities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <select className="form-select" style={{ width: 'auto' }}
            value={filters.assignee_id} onChange={e => setFilters({ ...filters, assignee_id: e.target.value })}>
            <option value="">All Assignees</option>
            <option value={user?.id}>My Tasks</option>
            {allUsers.filter(u => u.id !== user?.id).map(u => (
              <option key={u.id} value={u.id}>{u.name}</option>
            ))}
          </select>
          {(filters.status || filters.priority || filters.assignee_id) && (
            <button className="btn btn-ghost btn-sm" onClick={() => setFilters({ status: '', priority: '', assignee_id: '' })}>
              <X size={14} /> Clear filters
            </button>
          )}
        </div>

        {/* Summary chips */}
        {overdueTasks.length > 0 && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
            background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.15)',
            borderRadius: 'var(--radius-sm)', marginBottom: 20
          }}>
            <AlertTriangle size={14} color="var(--danger)" />
            <span style={{ fontSize: '0.85rem', color: 'var(--danger)', fontWeight: 600 }}>
              {overdueTasks.length} overdue task{overdueTasks.length !== 1 ? 's' : ''} need attention
            </span>
          </div>
        )}

        {loading ? (
          <div style={{ color: 'var(--text-muted)', padding: 20 }}>Loading tasks...</div>
        ) : tasks.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">✅</div>
            <div className="empty-title">No tasks found</div>
            <div className="empty-desc">Adjust filters or create tasks from a project</div>
          </div>
        ) : (
          <div className="tasks-grid">
            {tasks.map(task => {
              const isOverdue = task.due_date && isPast(parseISO(task.due_date)) && task.status !== 'done';
              return (
                <div key={task.id} className="task-card" onClick={() => setSelectedTask(task.id)}>
                  <div className="task-priority-dot" style={{ background: PRIORITY_COLORS[task.priority] }} />
                  <div className="task-info">
                    <div className="task-title">{task.title}</div>
                    <div className="task-meta">
                      <span style={{ color: 'var(--accent)', fontSize: '0.72rem' }}>{task.project_name}</span>
                      {task.due_date && (
                        <span className={isOverdue ? 'overdue-dot' : ''}>
                          {isOverdue && <AlertTriangle size={10} />}
                          {formatDistanceToNow(parseISO(task.due_date), { addSuffix: true })}
                        </span>
                      )}
                      {task.assignee_name && <span>→ {task.assignee_name}</span>}
                    </div>
                  </div>
                  <div className="task-badges">
                    <span className={`badge badge-${task.priority}`}>{task.priority}</span>
                    <span className={`badge badge-${task.status}`}>{STATUS_LABELS[task.status]}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {selectedTask && (
        <TaskDetailModal
          taskId={selectedTask}
          members={allUsers}
          onClose={() => setSelectedTask(null)}
          onSaved={handleTaskSaved}
          onDeleted={handleTaskDeleted}
        />
      )}
    </>
  );
}
