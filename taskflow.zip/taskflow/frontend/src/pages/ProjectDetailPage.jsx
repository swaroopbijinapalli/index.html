import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { formatDistanceToNow, parseISO, isPast } from 'date-fns';
import {
  Plus, X, AlertTriangle, UserPlus, ArrowLeft,
  Calendar, MessageSquare, ChevronRight
} from 'lucide-react';

const PRIORITY_COLORS = { low: '#64748b', medium: '#f59e0b', high: '#f97316', critical: '#ff3366' };
const STATUS_COLS = [
  { key: 'todo', label: 'To Do', color: 'var(--text-muted)' },
  { key: 'in_progress', label: 'In Progress', color: 'var(--accent)' },
  { key: 'review', label: 'Review', color: 'var(--accent-2)' },
  { key: 'done', label: 'Done', color: 'var(--success)' },
];

function Avatar({ name, color, size = 28 }) {
  const initials = name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  return (
    <div style={{
      width: size, height: size, borderRadius: 8, flexShrink: 0,
      background: color || '#6366f1', display: 'flex', alignItems: 'center',
      justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: size * 0.3
    }}>{initials}</div>
  );
}

function TaskModal({ task, members, projectId, onClose, onSaved, onDeleted }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    title: task?.title || '',
    description: task?.description || '',
    status: task?.status || 'todo',
    priority: task?.priority || 'medium',
    assignee_id: task?.assignee_id || '',
    due_date: task?.due_date ? task.due_date.split('T')[0] : '',
  });
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const isEdit = !!task;

  useEffect(() => {
    if (task?.id) {
      api.get(`/tasks/${task.id}`).then(res => setComments(res.data.comments || []));
    }
  }, [task?.id]);

  const handleSave = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isEdit) {
        const res = await api.put(`/tasks/${task.id}`, form);
        toast.success('Task updated');
        onSaved(res.data.task);
      } else {
        const res = await api.post('/tasks', { ...form, project_id: projectId });
        toast.success('Task created');
        onSaved(res.data.task);
      }
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save task');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this task?')) return;
    await api.delete(`/tasks/${task.id}`);
    toast.success('Task deleted');
    onDeleted(task.id);
    onClose();
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const res = await api.post(`/tasks/${task.id}/comments`, { content: newComment });
    setComments(c => [...c, res.data.comment]);
    setNewComment('');
    toast.success('Comment added');
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 600 }}>
        <div className="modal-header">
          <div className="modal-title">{isEdit ? 'Edit Task' : 'New Task'}</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSave}>
            <div className="form-group">
              <label className="form-label">Title *</label>
              <input className="form-input" placeholder="What needs to be done?"
                value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea className="form-textarea" placeholder="Add details..."
                value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Status</label>
                <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="todo">To Do</option>
                  <option value="in_progress">In Progress</option>
                  <option value="review">Review</option>
                  <option value="done">Done</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Priority</label>
                <select className="form-select" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="critical">Critical</option>
                </select>
              </div>
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Assignee</label>
                <select className="form-select" value={form.assignee_id} onChange={e => setForm({ ...form, assignee_id: e.target.value })}>
                  <option value="">Unassigned</option>
                  {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Due Date</label>
                <input className="form-input" type="date"
                  value={form.due_date} onChange={e => setForm({ ...form, due_date: e.target.value })} />
              </div>
            </div>
            <div className="modal-footer">
              {isEdit && (
                <button type="button" className="btn btn-danger btn-sm" onClick={handleDelete}>
                  Delete
                </button>
              )}
              <div style={{ flex: 1 }} />
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Saving...' : isEdit ? 'Update Task' : 'Create Task'}
              </button>
            </div>
          </form>

          {isEdit && (
            <div style={{ marginTop: 24, borderTop: '1px solid var(--border)', paddingTop: 20 }}>
              <div style={{ fontWeight: 700, fontSize: '0.85rem', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                <MessageSquare size={14} /> Comments ({comments.length})
              </div>
              <div style={{ maxHeight: 200, overflowY: 'auto', marginBottom: 12 }}>
                {comments.map(c => (
                  <div key={c.id} className="comment">
                    <Avatar name={c.author_name} color={c.avatar_color} size={30} />
                    <div className="comment-body">
                      <div className="comment-header">
                        <span className="comment-author">{c.author_name}</span>
                        <span className="comment-time">{formatDistanceToNow(parseISO(c.created_at), { addSuffix: true })}</span>
                      </div>
                      <div className="comment-text">{c.content}</div>
                    </div>
                  </div>
                ))}
                {comments.length === 0 && <div style={{ color: 'var(--text-muted)', fontSize: '0.82rem' }}>No comments yet.</div>}
              </div>
              <form onSubmit={handleComment} style={{ display: 'flex', gap: 8 }}>
                <input className="form-input" style={{ flex: 1 }} placeholder="Add a comment..."
                  value={newComment} onChange={e => setNewComment(e.target.value)} />
                <button type="submit" className="btn btn-secondary btn-sm">Post</button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AddMemberModal({ projectId, onClose, onAdded }) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('member');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post(`/projects/${projectId}/members`, { email, role });
      toast.success('Member added!');
      onAdded(res.data.user);
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to add member');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 400 }}>
        <div className="modal-header">
          <div className="modal-title">Add Member</div>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input className="form-input" type="email" placeholder="colleague@company.com"
                value={email} onChange={e => setEmail(e.target.value)} required />
            </div>
            <div className="form-group">
              <label className="form-label">Role</label>
              <select className="form-select" value={role} onChange={e => setRole(e.target.value)}>
                <option value="member">Member</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                <UserPlus size={15} /> {loading ? 'Adding...' : 'Add Member'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function ProjectDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [project, setProject] = useState(null);
  const [members, setMembers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [taskModal, setTaskModal] = useState(null); // null | 'new' | task object
  const [memberModal, setMemberModal] = useState(false);
  const [activeTab, setActiveTab] = useState('board');

  const fetchData = useCallback(async () => {
    try {
      const [projRes, taskRes] = await Promise.all([
        api.get(`/projects/${id}`),
        api.get(`/tasks?project_id=${id}`)
      ]);
      setProject(projRes.data.project);
      setMembers(projRes.data.members);
      setTasks(taskRes.data.tasks);
    } catch {
      toast.error('Failed to load project');
      navigate('/projects');
    } finally {
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleTaskSaved = (saved) => {
    setTasks(prev => {
      const idx = prev.findIndex(t => t.id === saved.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = saved;
        return next;
      }
      return [saved, ...prev];
    });
  };

  const handleTaskDeleted = (taskId) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const handleStatusChange = async (task, newStatus) => {
    const res = await api.put(`/tasks/${task.id}`, { status: newStatus });
    handleTaskSaved(res.data.task);
  };

  const handleRemoveMember = async (userId) => {
    if (!window.confirm('Remove this member?')) return;
    await api.delete(`/projects/${id}/members/${userId}`);
    setMembers(m => m.filter(x => x.id !== userId));
    toast.success('Member removed');
  };

  if (loading) return <div style={{ padding: 40, color: 'var(--text-muted)' }}>Loading project...</div>;
  if (!project) return null;

  const tasksByStatus = STATUS_COLS.reduce((acc, col) => {
    acc[col.key] = tasks.filter(t => t.status === col.key);
    return acc;
  }, {});

  const progress = tasks.length > 0
    ? Math.round((tasks.filter(t => t.status === 'done').length / tasks.length) * 100) : 0;

  return (
    <>
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, flex: 1 }}>
          <button className="btn btn-ghost btn-icon" onClick={() => navigate('/projects')}>
            <ArrowLeft size={18} />
          </button>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 4 }}>
              <div className="page-title">{project.name}</div>
              <span className={`badge badge-${project.status}`}>{project.status}</span>
            </div>
            {project.description && (
              <div className="page-subtitle">{project.description}</div>
            )}
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 8 }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                {members.slice(0, 5).map(m => (
                  <Avatar key={m.id} name={m.name} color={m.avatar_color} size={28} />
                ))}
                {members.length > 5 && (
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>+{members.length - 5}</span>
                )}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 80, height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg, var(--accent), var(--accent-2))', borderRadius: 2 }} />
                </div>
                <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{progress}%</span>
              </div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-secondary btn-sm" onClick={() => setMemberModal(true)}>
            <UserPlus size={14} /> Add Member
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => setTaskModal('new')}>
            <Plus size={14} /> Add Task
          </button>
        </div>
      </div>

      <div className="page-body">
        {/* Tabs */}
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 24 }}>
          <div className="tab-nav">
            {['board', 'list', 'members'].map(tab => (
              <button key={tab} className={`tab-btn ${activeTab === tab ? 'active' : ''}`}
                onClick={() => setActiveTab(tab)}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            {tasks.length} task{tasks.length !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Board View */}
        {activeTab === 'board' && (
          <div className="kanban-board">
            {STATUS_COLS.map(col => (
              <div key={col.key} className="kanban-col">
                <div className="kanban-col-header">
                  <div className="kanban-col-title" style={{ color: col.color }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: col.color }} />
                    {col.label}
                  </div>
                  <div className="kanban-col-count">{tasksByStatus[col.key].length}</div>
                </div>
                <div className="kanban-tasks">
                  {tasksByStatus[col.key].map(task => {
                    const isOverdue = task.due_date && isPast(parseISO(task.due_date)) && task.status !== 'done';
                    return (
                      <div key={task.id} className="kanban-task" onClick={() => setTaskModal(task)}>
                        <div className="kanban-task-title">{task.title}</div>
                        <div className="kanban-task-footer">
                          <span className={`badge badge-${task.priority}`}>{task.priority}</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            {isOverdue && <AlertTriangle size={12} color="var(--danger)" />}
                            {task.due_date && (
                              <span style={{ fontSize: '0.7rem', color: isOverdue ? 'var(--danger)' : 'var(--text-muted)' }}>
                                <Calendar size={10} style={{ display: 'inline', marginRight: 2 }} />
                                {formatDistanceToNow(parseISO(task.due_date), { addSuffix: true })}
                              </span>
                            )}
                            {task.assignee_name && (
                              <Avatar name={task.assignee_name} color={task.assignee_color} size={22} />
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <button className="btn btn-ghost btn-sm" style={{ width: '100%', justifyContent: 'flex-start', marginTop: 4 }}
                    onClick={() => setTaskModal('new')}>
                    <Plus size={14} /> Add task
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* List View */}
        {activeTab === 'list' && (
          <div>
            {tasks.length === 0 ? (
              <div className="empty-state">
                <div className="empty-title">No tasks yet</div>
                <button className="btn btn-primary btn-sm" style={{ marginTop: 16 }} onClick={() => setTaskModal('new')}>
                  <Plus size={14} /> Create first task
                </button>
              </div>
            ) : (
              <div className="tasks-grid">
                {tasks.map(task => {
                  const isOverdue = task.due_date && isPast(parseISO(task.due_date)) && task.status !== 'done';
                  return (
                    <div key={task.id} className="task-card" onClick={() => setTaskModal(task)}>
                      <div className="task-priority-dot" style={{ background: PRIORITY_COLORS[task.priority] }} />
                      <div className="task-info">
                        <div className="task-title">{task.title}</div>
                        <div className="task-meta">
                          {task.due_date && (
                            <span className={isOverdue ? 'overdue-dot' : ''}>
                              {isOverdue && <AlertTriangle size={10} />}
                              {formatDistanceToNow(parseISO(task.due_date), { addSuffix: true })}
                            </span>
                          )}
                          {task.assignee_name && <span>→ {task.assignee_name}</span>}
                        </div>
                      </div>
                      <div className="task-badges">
                        <span className={`badge badge-${task.priority}`}>{task.priority}</span>
                        <span className={`badge badge-${task.status}`}>
                          {task.status.replace('_', ' ')}
                        </span>
                        <ChevronRight size={14} color="var(--text-muted)" />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Members View */}
        {activeTab === 'members' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
            {members.map(m => (
              <div key={m.id} className="card card-sm" style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <Avatar name={m.name} color={m.avatar_color} size={40} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{m.name}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{m.email}</div>
                  <span className={`badge ${m.role === 'admin' ? 'badge-in_progress' : 'badge-todo'}`} style={{ marginTop: 4 }}>
                    {m.role}
                  </span>
                </div>
                {user?.role === 'admin' && m.id !== user.id && (
                  <button className="btn btn-ghost btn-icon btn-sm" onClick={() => handleRemoveMember(m.id)}>
                    <X size={14} />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {taskModal && (
        <TaskModal
          task={taskModal === 'new' ? null : taskModal}
          members={members}
          projectId={id}
          onClose={() => setTaskModal(null)}
          onSaved={handleTaskSaved}
          onDeleted={handleTaskDeleted}
        />
      )}

      {memberModal && (
        <AddMemberModal
          projectId={id}
          onClose={() => setMemberModal(false)}
          onAdded={m => setMembers(prev => [...prev, m])}
        />
      )}
    </>
  );
}
