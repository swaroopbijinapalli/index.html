import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { LogIn, Zap, Shield, Users } from 'lucide-react';

export default function LoginPage() {
  const { login } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Welcome back!');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-art">
        <div className="auth-art-grid" />
        <div className="auth-art-content">
          <div className="auth-logo">TaskFlow</div>
          <div className="auth-tagline">team productivity redefined</div>
          <div className="auth-features">
            {[
              { icon: <Zap size={18} color="var(--accent)" />, text: 'Real-time task tracking & status updates' },
              { icon: <Shield size={18} color="var(--accent-2)" />, text: 'Role-based access — Admin & Member controls' },
              { icon: <Users size={18} color="var(--success)" />, text: 'Collaborate across projects & teams' },
            ].map((f, i) => (
              <div className="auth-feature" key={i}>
                <div className="auth-feature-icon">{f.icon}</div>
                <span className="auth-feature-text">{f.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="auth-form-panel">
        <div className="auth-form-container">
          <div className="auth-form-title">Welcome back</div>
          <div className="auth-form-subtitle">Sign in to your workspace</div>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input
                className="form-input"
                type="email"
                placeholder="you@company.com"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-input"
                type="password"
                placeholder="••••••••"
                value={form.password}
                onChange={e => setForm({ ...form, password: e.target.value })}
                required
              />
            </div>

            <div style={{ marginTop: 8 }}>
              <button className="btn btn-primary btn-full" type="submit" disabled={loading}>
                <LogIn size={16} />
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </div>
          </form>

          <div className="auth-link">
            Don't have an account? <Link to="/signup">Create one</Link>
          </div>

          <div style={{ marginTop: 28, padding: 16, background: 'var(--bg-card)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1, color: 'var(--text-muted)', marginBottom: 8 }}>
              Demo Credentials
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', lineHeight: 1.8 }}>
              <div>Admin: admin@demo.com / admin123</div>
              <div>Member: member@demo.com / member123</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
