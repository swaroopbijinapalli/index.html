import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { formatDistanceToNow, isPast, parseISO } from 'date-fns';
import {
  CheckCircle2, Clock, AlertTriangle, FolderKanban,
  TrendingUp, Flame, ListTodo, Eye
} from 'lucide-react';

const PRIORITY_COLORS = { low: '#64748b', medium: '#f59e0b', high: '#f97316', critical: '#ff3366' };
const STATUS_LABELS = { todo: 'To Do', in_progress: 'In Progress', review: 'Review', done: 'Done' };

function Avatar({ name, color, size = 28 }) {
  const initials = name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  return (
    <div className="user-avatar" style={{
      background: color || '#6366f1',
      width: size, height: size,
      borderRadius: 8, fontSize: size * 0.3,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0, color: '#fff', fontWeight: 700
    }}>
      {initials}
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard/stats').then(res => {
      setData(res.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) return (
    <div style={{ padding: 40, color: 'var(--text-muted)' }}>Loading dashboard...</div>
  );

  const { stats, recentTasks = [], overdueTasks = [], priorityBreakdown = [] } = data || {};

  const statCards = [
    { label: 'Total Tasks', value: stats?.total ?? 0, icon: <ListTodo size={40} />, color: 'blue' },
    { label: 'In Progress', value: stats?.in_progress ?? 0, icon: <TrendingUp size={40} />, color: 'purple' },
    { label: 'Completed', value: stats?.done ?? 0, icon: <CheckCircle2 size={40} />, color: 'green' },
    { label: 'Overdue', value: stats?.overdue ?? 0, icon: <AlertTriangle size={40} />, color: 'red' },
    { label: 'My Tasks', value: stats?.my_tasks ?? 0, icon: <Flame size={40} />, color: 'orange' },
    { label: 'Projects', value: stats?.projects ?? 0, icon: <FolderKanban size={40} />, color: 'blue' },
  ];

  return (
    <>
      <div className="page-header">
        <div>
          <div className="page-title">
            Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'},{' '}
            {user?.name?.split(' ')[0]} 👋
          </div>
          <div className="page-subtitle">Here's what's happening across your workspace</div>
        </div>
      </div>

      <div className="page-body">
        {/* Stats */}
        <div className="stats-grid">
          {statCards.map((s, i) => (
            <div className={`stat-card ${s.color}`} key={i}>
              <div className="stat-label">{s.label}</div>
              <div className="stat-value">{s.value}</div>
              <div className="stat-icon">{s.icon}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 24 }}>
          {/* Recent Tasks */}
          <div>
            <div className="flex-between" style={{ marginBottom: 16 }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 700 }}>
                Recent Activity
              </h2>
            </div>
            <div className="tasks-grid">
              {recentTasks.length === 0 && (
                <div className="empty-state">
                  <div className="empty-icon">📋</div>
                  <div className="empty-title">No tasks yet</div>
                  <div className="empty-desc">Create your first project to get started</div>
                </div>
              )}
              {recentTasks.map(task => {
                const isOverdue = task.due_date && isPast(parseISO(task.due_date)) && task.status !== 'done';
                return (
                  <div key={task.id} className="task-card" onClick={() => navigate('/tasks')}>
                    <div className="task-priority-dot" style={{ background: PRIORITY_COLORS[task.priority] }} />
                    <div className="task-info">
                      <div className="task-title">{task.title}</div>
                      <div className="task-meta">
                        <span>{task.project_name}</span>
                        {task.due_date && (
                          <span className={isOverdue ? 'overdue-dot' : ''}>
                            {isOverdue && <AlertTriangle size={10} />}
                            {formatDistanceToNow(parseISO(task.due_date), { addSuffix: true })}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="task-badges">
                      {task.assignee_name && (
                        <Avatar name={task.assignee_name} color={task.assignee_color} size={26} />
                      )}
                      <span className={`badge badge-${task.status}`}>
                        {STATUS_LABELS[task.status]}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right panel */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {/* Overdue */}
            {overdueTasks.length > 0 && (
              <div className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                  <AlertTriangle size={16} color="var(--danger)" />
                  <span style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--danger)' }}>
                    Overdue ({overdueTasks.length})
                  </span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {overdueTasks.map(task => (
                    <div key={task.id} style={{
                      padding: '10px 14px',
                      background: 'rgba(239,68,68,0.06)',
                      border: '1px solid rgba(239,68,68,0.15)',
                      borderRadius: 'var(--radius-sm)',
                      cursor: 'pointer'
                    }} onClick={() => navigate('/tasks')}>
                      <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>
                        {task.title}
                      </div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', gap: 8 }}>
                        <span>{task.project_name}</span>
                        <span style={{ color: 'var(--danger)' }}>
                          {formatDistanceToNow(parseISO(task.due_date), { addSuffix: true })}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Priority Breakdown */}
            <div className="card">
              <div style={{ fontWeight: 700, fontSize: '0.9rem', marginBottom: 16 }}>Priority Breakdown</div>
              {['critical', 'high', 'medium', 'low'].map(p => {
                const item = priorityBreakdown.find(x => x.priority === p);
                const count = item?.count || 0;
                const max = Math.max(...priorityBreakdown.map(x => x.count), 1);
                return (
                  <div key={p} style={{ marginBottom: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span style={{ fontSize: '0.75rem', textTransform: 'capitalize', color: 'var(--text-secondary)', fontWeight: 600 }}>{p}</span>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{count}</span>
                    </div>
                    <div style={{ height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
                      <div style={{
                        height: '100%', borderRadius: 2,
                        width: `${(count / max) * 100}%`,
                        background: PRIORITY_COLORS[p],
                        transition: 'width 0.5s ease'
                      }} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick actions */}
            <div className="card">
              <div style={{ fontWeight: 700, fontSize: '0.9rem', marginBottom: 14 }}>Quick Actions</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <button className="btn btn-secondary btn-full" onClick={() => navigate('/projects')}>
                  <FolderKanban size={15} /> View Projects
                </button>
                <button className="btn btn-secondary btn-full" onClick={() => navigate('/tasks')}>
                  <Eye size={15} /> View All Tasks
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
